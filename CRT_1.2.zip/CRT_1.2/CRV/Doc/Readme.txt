

                      CRV - Version: 1.0
               CRT Cascade Routing Visualization Using ArcGIS


NOTE: Any use of trade, product or firm names is for descriptive purposes 
      only and does not imply endorsement by the U.S. Government.

The U.S. Geological Survey Cascade Routing Tool (CRT) is a standalone computer application 
for hydrologic models, including the Coupled Groundwater Surface-Water Flow Model (GSFLOW),
and Precipitation-Runoff Modeling System (PRMS). Included with CRT is the Cascade 
Routing Visualization (CRV) Toolbox. CRV calls and executes the standalone CRT
executable to generate the necessary vis.txt file. Alternatively, a valid vis.txt file 
can be provided by the user and imported as input for the tool. CRV creates the cascade 
links feature class (CascadeFlow_XX) and cascade types feature class (CascadeType_XX)
in a file-based geodatabase (CRV_XX.gdb), in a folder named CRV_XX, where XX is a number
that identifies each subsequent execution of CRV. This toolbox is designed to be accessed 
using ArcGIS Desktop software (version 10.0). This toolbox is built on top of standard 
functionality included in ArcGIS Desktop running at the ArcEditor license level. 
ArcGIS is a commercial GIS software system produced by ESRI, Inc. (http://www.esri.com).
The CRV Toolbox is not supported by ESRI, Inc. or its technical support staff. 


A. DIRECTORY STRUCTURE

The Cascade Routing Visualization ArcGIS Toolbox folder, "CRV," has the following structure:

   |
   |--CRV
   |    |--Doc           ; Readme file
        |--Scratch       ; Drive for storage of toolbox data
   |    |--Scripts       ; Python scripts used to execute CRV
   |    |--Toolbox       ; ArcGIS Toobox file
   |    |--ToolData      ; Data for ArcGIS Toobox


B. INSTALLING

1. Download the CRT release from the USGS Software webpages
     (http://water.usgs.gov/software/lists/groundwater/).
2. Open the "CRT_1.1.1.zip" file and extract all CRT files to the selected 
      installation directory.
3. Open the CRV Directory ("CRT_1.1.1\CRV"). This folder contains a 
    collection of files and folders used for the CRV toolbox. 
4. Start ArcMap or open an existing ArcMap document. It might be helpful to 
    have a model grid and other data for the study area included for reference.
    GIS data sets for example applications are available as a separate file on the CRT 
    software page http://water.usgs.gov/ogw/CRT/. Step-by-step instructions are provided 
    below for adding the toolbox to ArcGIS 10.0. For more details and information about 
    managing toolboxes within ArcGIS, see the ArcGIS online help article "Adding and 
    Removing Toolboxes."
5. From ArcMap's main menu, select "Window -> ArcToolbox." to display the 
    ArcToolbox window within ArcMap. 
6. In the ArcToolbox window, right-click �Add Toolbox� from the context menu 
    that appears.
7. Browse in the resulting dialog box to the  folder that contains the CRV toolbox
    ("CRT_1.1.1\CRV\Toolbox") and select the file "CRV.tbx."
8. Click the "Open" button to add "CRV.tbx" to ArcMap.
9. Select the file �CRV.tbx� and click the �Open� Button.
    If the ArcMap document is saved, the reference to the CRV toolbox 
    will be saved as well, and the toolbox will still be available when the current
    document is opened at a later time. Additionally, CRV can be made available 
    in all ArcMap documents by right clicking in the ArcToolbox window and 
    selecting �Save Settings� and choosing �To Default�.  

C. EXECUTING THE SOFTWARE

The tools can be accessed the same way standard ArcGIS tools are used: by double-clicking 
on the name of the toolbox, or right clicking the toolbox to access its properties or 
documentation.

1. Expand �CRV.tbx� and double-click �CRV� script.
2. Enter in �User Workspace� either (a) The folder location of CRT executable and all 
    necessary input files for a CRT run or (b) The folder location of vis.txt from a successfully 
    completed execution of CRT. Note that the �Visualization Only� checkbox must be selected for 
    this option.
3. The check box for �Visualization only� signals that the CRT executable will not be
    run as a part of this visualization, and a valid vis.txt file is in the 'User Workspace'.
4. Specify the coordinate system; otherwise, the output-feature classes will inherit
    the coordinate system definition from the active data frame in the current ArcMap document:
    a)	Click �Environments� button or go to the �Geoprocessing� menu and select �Environments�  
    b)	Expand �Output Coordinates� and specify a coordinate system
    c)	Click �OK.�
5. Click �OK� to run CRV.

CRV will run CRT to compute cascades or use the user provided vis.txt file. CRV will display
the results in the current ArcMap document, where users can verify cascades. If cascades need 
to be modified, CRT input can be adjusted and CRV can re-execute CRT to recompute cascades.

