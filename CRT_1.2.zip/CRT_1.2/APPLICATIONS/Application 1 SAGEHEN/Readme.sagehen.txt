
                      Sagehen Creek Basin Sample Application for CRT
                                 September 2015
 
A sample application with CRT input and output data sets is provided in this
subdirectory to verify that CRT is correctly installed and running on the system.
The sample application also may be looked at as an example of how to use the
program. The sample CRT application is for the Sagehen Creek Basin, and is 
described in the CRT documentation (Henson and others, 2013).

Three directories of input files are provided to run the sample application
for different model configurations available for evaluation by CRT. The input 
files found in the three subdirectories are for the following three simulation 
conditions:

A. Application to develop surface cascades with all streams active and the use of 
   the CRT Fill Procedure to rectify undeclared swales.
B. Application to develop PRMS-only groundwater cascades using the steady-state
   groundwater head elevations from a groundwater model and using the CRT fill 
   procedure to rectify local depressions in the potentiometric surface to ensure 
   continuous cascade flow pathways.
C. Application to illustrate the STRMFLG = 2 option for defining connectivity 
   between HRUs containing streams and stream segments as well as writing global
   reach scale information to CRT output.
   
To run CRT double-click on the Windows batch file (CRT.bat) in the application 
subdirectory or place the 32-bit or 64-bit CRT executable in the same directory as
the application input files and double-click on the executable (.exe) file. 

A CRT log file, outputstat.txt, will be written directly to the application 
subdirectory in which the batch or executable files are located. Several types of
output files will be generated in the application subdirectory, each of which is 
described in detail in the CRT documentation. 

Reference:

Henson, W.R., Medina, R.L., Mayers, C.J., Niswonger, R.G., and Regan, R.S., 2013,
CRT�Cascade Routing Tool to define and visualize flow paths for grid-based 
watershed models: U.S. Geological Survey Techniques and Methods 6-D2, 28 p.
